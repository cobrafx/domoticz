from adapters.philips.hue_dimmer_switch import HueDimmerSwitch


philips_adapters = {
    '324131092621': HueDimmerSwitch,        # Philips Hue dimmer switch
}