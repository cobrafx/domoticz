from adapters.gledopto.GLC0082ID import GLC0082ID


gledopto_adapters = {
    'GL-C-008-2ID': GLC0082ID,          # Zigbee LED controller RGB + CCT (2 ID)
}
