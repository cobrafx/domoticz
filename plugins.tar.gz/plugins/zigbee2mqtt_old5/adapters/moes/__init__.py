from adapters.moes.BRT100TRV import BRT100TRV


moes_adapters = {
    'BRT-100-TRV': BRT100TRV,                    # Moes BRT-100-TRV Radiator valve with thermostat
}
