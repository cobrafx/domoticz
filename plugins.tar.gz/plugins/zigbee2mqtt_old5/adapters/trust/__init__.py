from adapters.trust.zyct202 import ZYCT202

trust_adapters = {
    'ZYCT-202': ZYCT202,                # Trust Remote control
}