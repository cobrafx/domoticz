#!/usr/bin/python3.7
import tinytuya
import time

device_id = 'bfc9b828c62aa43667rdug'
local_key = 'zP=pynGe%7IT%_q5'
ip_address = '192.168.0.78'
max_charge = 30
min_charge = 30

d = tinytuya.OutletDevice(device_id, ip_address, local_key)
d.set_version(3.3)

# Відправляємо команду зупинки зарядки
d.set_value(124, "CloseCharging")

# Очікуємо, поки статус не стане 'WaitOperation'
while True:
    data = d.status()
    if data['dps']['124'] == "WaitOperation":
        print("Статус 'WaitOperation' досягнутий.")
        break
    else:
        print("Поточний статус:", data['dps']['124'])
    time.sleep(1)

# Після досягнення 'WaitOperation' відправляємо наступну команду
d.set_value(115, min_charge)

# Очікуємо, поки статус не стане 'WaitOperation'
while True:
    data = d.status()
    if data['dps']['115'] == min_charge:
        print("Встановлено:", min_charge, "A")
        break
    else:
        print("Поточний A:", data['dps']['115'])
    time.sleep(1)

# Очікуємо, поки статус не стане 'WaitOperation'
while True:
    data = d.status()
    if data['dps']['101'] == "connect":
        print("Статус 'connect' досягнутий.")
        break
    else:
        d.set_value(124, "OpenCharging")
        print("Поточний статус:", data['dps']['101'])
    time.sleep(1)

print("Наступна команда відправлена.")

data = d.status()
print('Device status: %r' % data)
