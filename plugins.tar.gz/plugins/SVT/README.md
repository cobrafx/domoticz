# SmartVirtualThermostat
Smart Virtual Thermostat python plugin for Domoticz home automation system

See https://www.domoticz.com/wiki/Plugins/Smart_Virtual_Thermostat.html for description and installation instructions
