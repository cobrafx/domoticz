#!/usr/bin/python3.7
import tinytuya

d = tinytuya.OutletDevice('bfc9b828c62aa43667rdug', '192.168.0.78', 'zP=pynGe%7IT%_q5')
d.set_version(3.3)
data = d.status() 
print('Device status: %r' % data)
