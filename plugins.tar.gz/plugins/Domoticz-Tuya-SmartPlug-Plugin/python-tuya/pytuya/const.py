version_tuple = (7, 0, 7)
version = __version__ = '%d.%d.%d' % version_tuple
__author__ = 'clach04'
