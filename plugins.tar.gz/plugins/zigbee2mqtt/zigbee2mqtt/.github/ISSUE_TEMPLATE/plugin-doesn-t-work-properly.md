---
name: Plugin doesn't work properly
about: 'Report any issues with plugin: crash, connection issue, no devices, etc.'
title: ''
labels: ''
assignees: ''

---

**Issue description**
Put general information here

**Additional information**
Zigbee2MQTT version:
Python version:
Domoticz version:
Plugin version:

**Logs**
Attach any additional logs here which might be useful: mqtt, domoticz, plugin logs
