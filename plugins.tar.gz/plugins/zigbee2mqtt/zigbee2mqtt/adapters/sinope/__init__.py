from adapters.sinope.TH1124ZB import TH1124ZB


sinope_adapters = {
    'TH1124ZB': TH1124ZB,             # Sinope Zigbee line volt thermostat
}