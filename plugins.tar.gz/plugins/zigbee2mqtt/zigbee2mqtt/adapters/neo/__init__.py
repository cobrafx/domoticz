from adapters.neo.NASAB02B0 import NASAB02B0

neo_adapters = {
    'NAS-AB02B0': NASAB02B0,        # Neo Temperature & humidity sensor and alarm
}