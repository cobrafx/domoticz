from adapters.life_control.MCLH08 import MCLH08


life_control_adapters = {
    'MCLH-08': MCLH08,      # LifeControl Air sensor
}
