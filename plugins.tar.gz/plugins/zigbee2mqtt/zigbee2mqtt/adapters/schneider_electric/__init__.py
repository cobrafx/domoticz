from adapters.schneider_electric.WV704R0A0902 import WV704R0A0902


schneider_adapters = {
    'WV704R0A0902': WV704R0A0902,             # Schneider Electric Wiser radiator thermostat
}